public interface Publicacao {

    String buscarTitulos(String titulo);
    void visualizarDetalhes();
}
